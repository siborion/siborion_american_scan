#include "curbase.h"

CurBase::CurBase(QObject *parent) :
    QObject(parent)
{
}

void CurBase::updatePatient()
{

}
